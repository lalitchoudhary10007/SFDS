import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SafeformPage } from './safeform';
import { AppHeaderComponentsModule } from '../../HeaderFooter/appheader.module';

@NgModule({
  declarations: [
    SafeformPage,
  ],
  imports: [
    IonicPageModule.forChild(SafeformPage),
    AppHeaderComponentsModule
  ],
  exports:[
  SafeformPage
  ]
})
export class SafeformPageModule {}
