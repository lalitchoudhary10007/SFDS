import { Component, Input, Output, EventEmitter } from '@angular/core'; // , /*Injectable,*/  Output, EventEmitter
import { FormGroup }         from '@angular/forms'; /*, FormBuilder, Validators*/
import { AppUtilsProvider, SessionHelperProvider } from '../providers/providers';
import { NavController, LoadingController ,AlertController } from 'ionic-angular';
@Component({
    selector   : 'appheader',
    templateUrl: 'appheader.html'
  })
  export class AppheaderComponent {
    @Input() backterms;
    @Output('CallBackEvent') EventsCallback: EventEmitter<any> = new EventEmitter();
    SelectedUser: any = {};
    SelectedJob: any = {};
    
      
    constructor(private navCtrl: NavController,public appUtils: AppUtilsProvider, public sessionHelper: SessionHelperProvider) { 
        this.appUtils.GetContractorLogoAndName();

        this.sessionHelper.GetValuesFromSession("SelectedUser").then((val) => {
          this.SelectedUser = JSON.parse(val);
        });
        this.sessionHelper.GetValuesFromSession("SelectedJob").then((val) => {
          this.SelectedJob = JSON.parse(val);
        });
    

      }
   
     ngOnInit(){
        console.log("**ON SUBMIT" ,this.backterms);
     }
   
     onSubmit(from) {
       console.log("**ON SUBMIT" ,from);
       this.EventsCallback.emit(from);
     }

     cancel() {
      
      }

     
  
  }
