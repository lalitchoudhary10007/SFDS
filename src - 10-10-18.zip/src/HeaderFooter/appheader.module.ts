import { NgModule } from '@angular/core';
import { AppheaderComponent } from '../HeaderFooter/AppHeader';
@NgModule({
    declarations: [AppheaderComponent],
    imports: [],
    exports: [AppheaderComponent]
})
export class AppHeaderComponentsModule {}